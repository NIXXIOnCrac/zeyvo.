#!/bin/bash
set -e
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3.10+ is required. Install it from python.org and try again."
  read -r -p "Press Return to exit..." _
  exit 1
fi
if ! python3 -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)"; then
  echo "Python 3.10 or newer is required. Please install a recent version from python.org."
  read -r -p "Press Return to exit..." _
  exit 1
fi
if [ ! -f .venv/bin/python ]; then
  echo "First run: preparing ZEYVO Classic Notch. Internet is required to install PySide6."
  python3 -m venv .venv
  .venv/bin/python -m pip install -r requirements.txt
fi
echo "Starting ZEYVO in the background. Use its menu-bar icon to open or quit."
nohup .venv/bin/python main.py > .venv/zeyvo-demo.log 2>&1 < /dev/null &
