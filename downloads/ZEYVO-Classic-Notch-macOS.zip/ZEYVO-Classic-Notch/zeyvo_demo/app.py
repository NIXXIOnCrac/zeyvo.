"""ZEYVO Classic Notch — tiny offline companion for Windows / macOS.

Transparent frameless top-center overlay. Classic flush-top notch geometry,
black-only style, simple panel and 30-second ZEYVO-only idle tuck-away.
No microphone, cloud services, or hidden computer-control capabilities.
"""
from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import QAbstractAnimation, QEasingCurve, QEvent, QRectF, Qt, QTimer, QVariantAnimation
from PySide6.QtGui import QAction, QColor, QFont, QIcon, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import (
    QApplication, QFrame, QHBoxLayout, QLabel, QLineEdit, QMenu,
    QPushButton, QSystemTrayIcon, QVBoxLayout, QWidget,
)

from .layout import IDLE_MS, OPEN, PEEK, REST, SIZES, anchored_position, label_for_mode
from .responses import reply


class NotchWindow(QWidget):
    def __init__(self, app: QApplication):
        super().__init__()
        self._app = app
        self._mode = REST
        self._anim: QVariantAnimation | None = None
        self._tray: QSystemTrayIcon | None = None
        self._last_question = ""
        self._screen = QApplication.primaryScreen()
        self._panel_alpha = 0.0

        self.setWindowTitle("ZEYVO — Classic Notch Demo")
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.Tool
            | Qt.WindowType.WindowStaysOnTopHint
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground, True)
        self.setMouseTracking(True)
        self.resize(SIZES[REST].width, SIZES[REST].height)
        self._position_at_top(SIZES[REST].width, SIZES[REST].height)

        self._idle = QTimer(self)
        self._idle.setSingleShot(True)
        self._idle.setInterval(IDLE_MS)
        self._idle.timeout.connect(self.tuck_away)

        self._notch_button = QPushButton(self)
        self._notch_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self._notch_button.setAccessibleName("Open ZEYVO")
        self._notch_button.setStyleSheet("QPushButton { background: transparent; border: 0; }")
        self._notch_button.clicked.connect(self.toggle)
        self._notch_button.setMouseTracking(True)

        self.panel = QFrame(self)
        self.panel.setObjectName("content")
        self.panel.setStyleSheet("QFrame#content { background: transparent; border: none; }")
        self.panel.hide()
        layout = QVBoxLayout(self.panel)
        layout.setContentsMargins(23, 8, 23, 14)
        layout.setSpacing(9)

        top_row = QHBoxLayout()
        self.title = QLabel("ZEYVO")
        self.title.setStyleSheet("color: #FFFFFF; font-size: 15px; font-weight: 650; letter-spacing: 1px;")
        self.offline = QLabel("OFFLINE DEMO")
        self.offline.setStyleSheet("color: #8D8D92; font-size: 10px; letter-spacing: .4px;")
        top_row.addWidget(self.title)
        top_row.addStretch(1)
        top_row.addWidget(self.offline)
        layout.addLayout(top_row)

        self.caption = QLabel("What can I help you with?")
        self.caption.setStyleSheet("color: #B8B8BC; font-size: 12px;")
        layout.addWidget(self.caption)

        self.response = QLabel("Hey. I'm ZEYVO. Ask me how I'm doing.")
        self.response.setObjectName("reply")
        self.response.setWordWrap(True)
        self.response.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.response.setMinimumHeight(87)
        self.response.setStyleSheet(
            "QLabel#reply {background:#1C1C1E;color:#F5F5F7;"
            "border:1px solid #303033;border-radius:15px;padding:15px;"
            "font-size:13px;}"
        )
        layout.addWidget(self.response, 1)

        chips = QHBoxLayout()
        chips.setSpacing(7)
        for prompt, spoken in [
            ("How are you?", "How are you?"),
            ("Tell a joke", "Tell me a joke"),
            ("The time", "What time is it?"),
        ]:
            button = QPushButton(prompt)
            button.setAccessibleName("Ask " + spoken)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setFixedHeight(31)
            button.setStyleSheet(
                "QPushButton{color:#E3E3E5;background:#242426;border:1px solid #353538;"
                "border-radius:15px;padding:0 10px;font-size:11px;}"
                "QPushButton:hover{background:#343437;border-color:#57575D;}"
            )
            button.clicked.connect(lambda _checked=False, message=spoken: self.ask(message))
            chips.addWidget(button)
        layout.addLayout(chips)

        entry = QHBoxLayout()
        entry.setSpacing(8)
        self.input = QLineEdit()
        self.input.setAccessibleName("Ask ZEYVO a question")
        self.input.setPlaceholderText("Ask ZEYVO…")
        self.input.setMinimumHeight(42)
        self.input.setStyleSheet(
            "QLineEdit{color:#FFFFFF;background:#1C1C1E;border:1px solid #38383B;"
            "border-radius:19px;padding:0 15px;font-size:13px;}"
            "QLineEdit:focus{border:1px solid #85858D;}"
        )
        self.input.returnPressed.connect(self.submit)
        self.input.textEdited.connect(lambda _text: self._restart_idle())
        self.submit_button = QPushButton("↑")
        self.submit_button.setAccessibleName("Send question")
        self.submit_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.submit_button.setFixedSize(40, 40)
        self.submit_button.setStyleSheet(
            "QPushButton{color:#111111;background:#F2F2F5;border:0;border-radius:20px;"
            "font-size:20px;font-weight:700;}"
            "QPushButton:hover{background:#DCDCE0;}"
        )
        self.submit_button.clicked.connect(self.submit)
        entry.addWidget(self.input, 1)
        entry.addWidget(self.submit_button)
        layout.addLayout(entry)

        footer = QHBoxLayout()
        self.privacy = QLabel("On-device · No API key · 30s auto-hide")
        self.privacy.setStyleSheet("color:#8B8B91;font-size:10px;")
        footer.addWidget(self.privacy)
        footer.addStretch(1)
        self.hide_button = QPushButton("Hide")
        self.hide_button.setAccessibleName("Hide ZEYVO to tiny top bump")
        self.hide_button.setStyleSheet(
            "QPushButton{color:#AAAAAF;background:transparent;border:0;font-size:11px;}"
            "QPushButton:hover{color:#FFFFFF;}"
        )
        self.hide_button.clicked.connect(self.tuck_away)
        footer.addWidget(self.hide_button)
        self.quit_button = QPushButton("Quit")
        self.quit_button.setAccessibleName("Quit ZEYVO Demo")
        self.quit_button.setStyleSheet(
            "QPushButton{color:#AAAAAF;background:transparent;border:0;font-size:11px;}"
            "QPushButton:hover{color:#FFFFFF;}"
        )
        self.quit_button.clicked.connect(self._app.quit)
        footer.addWidget(self.quit_button)
        layout.addLayout(footer)

        self._update_positions()
        self._setup_tray()
        self._idle.start(IDLE_MS)
        # Reset the 30-second timer only on interaction with ZEYVO widgets.
        # In particular, movement elsewhere on the computer does not count.
        self._app.installEventFilter(self)
        if self._screen is not None:
            self._screen.geometryChanged.connect(self._reposition)
            self._screen.availableGeometryChanged.connect(self._reposition)

    def _position_at_top(self, width: int, height: int) -> None:
        screen = self._screen or QApplication.primaryScreen()
        if screen is None:
            return
        physical = screen.geometry()
        if sys.platform == "darwin":
            # On Macs with menu bars or camera cutouts, don't cover system UI.
            # This anchors under the usable top safe area; Qt cannot force its
            # window into or above protected macOS full-screen / notch regions.
            safe_top = screen.availableGeometry().top()
        else:
            safe_top = physical.top()
        x = physical.left() + (physical.width() - width) // 2
        self.setGeometry(x, safe_top, width, height)

    def _reposition(self, *_args) -> None:
        self._position_at_top(self.width(), self.height())

    def _update_positions(self) -> None:
        w, h = self.width(), self.height()
        self._notch_button.setGeometry(0, 0, w, min(39, h))
        self._notch_button.setToolTip(label_for_mode(self._mode))
        self._notch_button.setAccessibleName(label_for_mode(self._mode))
        # The black notch is a single connected silhouette, not a detached pill.
        self.panel.setGeometry(0, 45, w, max(1, h - 45))
        self._notch_button.raise_()

    def _setup_tray(self) -> None:
        if not QSystemTrayIcon.isSystemTrayAvailable():
            return
        tray = QSystemTrayIcon(self._icon(), self._app)
        tray.setToolTip("ZEYVO — notch demo")
        menu = QMenu()
        show_action = QAction("Open ZEYVO", menu)
        show_action.triggered.connect(self.expand)
        menu.addAction(show_action)
        rest_action = QAction("Show small notch", menu)
        rest_action.triggered.connect(self.show_notch)
        menu.addAction(rest_action)
        hide_action = QAction("Hide to tiny bump", menu)
        hide_action.triggered.connect(self.tuck_away)
        menu.addAction(hide_action)
        menu.addSeparator()
        quit_action = QAction("Quit ZEYVO", menu)
        quit_action.triggered.connect(self._app.quit)
        menu.addAction(quit_action)
        tray.setContextMenu(menu)
        tray.activated.connect(self._tray_clicked)
        tray.show()
        self._tray = tray

    @staticmethod
    def _icon() -> QIcon:
        path = Path(__file__).resolve().parent / "assets" / "icon.png"
        return QIcon(str(path)) if path.is_file() else QIcon()

    def _tray_clicked(self, reason: QSystemTrayIcon.ActivationReason) -> None:
        if reason in (
            QSystemTrayIcon.ActivationReason.Trigger,
            QSystemTrayIcon.ActivationReason.DoubleClick,
        ):
            self.expand()

    def eventFilter(self, obj, event):  # type: ignore[override]
        if event.type() in (
            QEvent.Type.MouseButtonPress,
            QEvent.Type.KeyPress,
            QEvent.Type.Wheel,
        ):
            widget = obj if isinstance(obj, QWidget) else None
            while widget is not None:
                if widget is self:
                    self._restart_idle()
                    break
                widget = widget.parentWidget()
        return super().eventFilter(obj, event)

    def _restart_idle(self) -> None:
        if self._mode != PEEK:
            self._idle.start(IDLE_MS)

    def enterEvent(self, event):  # type: ignore[override]
        if self._mode == PEEK:
            self.show_notch()
        super().enterEvent(event)

    def toggle(self) -> None:
        if self._mode == OPEN:
            self.show_notch()
        else:
            self.expand()

    def expand(self) -> None:
        self._change_mode(OPEN)
        self.show()
        self.raise_()
        self.activateWindow()
        QTimer.singleShot(285, self._focus_if_open)

    def _focus_if_open(self) -> None:
        if self._mode == OPEN:
            self.input.setFocus()

    def show_notch(self) -> None:
        self._change_mode(REST)
        self.show()
        self.raise_()

    def tuck_away(self) -> None:
        self._change_mode(PEEK)

    def _change_mode(self, target: str) -> None:
        if target == self._mode and (not self._anim or self._anim.state() != QAbstractAnimation.State.Running):
            self._restart_idle()
            return
        if self._anim and self._anim.state() == QAbstractAnimation.State.Running:
            self._anim.stop()
        self._mode = target
        self._idle.stop()
        if target != PEEK:
            self._idle.start(IDLE_MS)
        self.input.clearFocus()
        self.panel.setVisible(target == OPEN)
        start = (self.width(), self.height())
        end = SIZES[target]
        anim = QVariantAnimation(self)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setDuration(285 if target == OPEN else 245)
        anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        anim.valueChanged.connect(lambda v, first=start, dest=end: self._step(float(v), first, dest))
        anim.finished.connect(self._animation_finished)
        self._anim = anim
        anim.start()

    def _step(self, v: float, start: tuple[int, int], end) -> None:
        width = round(start[0] + (end.width - start[0]) * v)
        height = round(start[1] + (end.height - start[1]) * v)
        self._position_at_top(width, height)
        self._panel_alpha = min(1.0, max(0.0, (height - 140) / 100))
        self.panel.setVisible(height > 190 and self._mode == OPEN)
        self._update_positions()
        self.update()

    def _animation_finished(self) -> None:
        self.panel.setVisible(self._mode == OPEN)
        self._update_positions()
        self.update()

    def ask(self, question: str) -> None:
        if self._mode != OPEN:
            self.expand()
        self._last_question = question
        self.response.setText("One moment…")
        self.input.clear()
        self._restart_idle()
        QTimer.singleShot(180, lambda q=question: self._answer(q))

    def _answer(self, question: str) -> None:
        if question != self._last_question:
            return
        self.response.setText(reply(question))
        self._restart_idle()

    def submit(self) -> None:
        question = self.input.text().strip()
        if question:
            self.ask(question)

    def keyPressEvent(self, event):  # type: ignore[override]
        if event.key() == Qt.Key.Key_Escape:
            self.show_notch()
            return
        super().keyPressEvent(event)

    def resizeEvent(self, event):  # type: ignore[override]
        self._update_positions()
        super().resizeEvent(event)

    @staticmethod
    def _silhouette(bounds: QRectF, radius: float) -> QPainterPath:
        """Classic notch: FLAT/flush top edge, softly rounded bottom corners.

        Intentionally not a pill / Dynamic Island. Only the two lower corners
        are rounded, with vertical sides and a flat black edge at the top.
        """
        x, y, w, h = bounds.x(), bounds.y(), bounds.width(), bounds.height()
        r = min(radius, h * .48, w * .2)
        p = QPainterPath()
        p.moveTo(x, y)
        p.lineTo(x + w, y)
        p.lineTo(x + w, y + h - r)
        p.quadTo(x + w, y + h, x + w - r, y + h)
        p.lineTo(x + r, y + h)
        p.quadTo(x, y + h, x, y + h - r)
        p.closeSubpath()
        return p

    def paintEvent(self, event):  # type: ignore[override]
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
        w, h = float(self.width()), float(self.height())
        shape = self._silhouette(QRectF(0, 0, w, h - .5), 21 if h > 52 else 13)
        painter.fillPath(shape, QColor(3, 3, 4))
        if h > 70:
            painter.setPen(QPen(QColor(255, 255, 255, 21), 1))
            painter.drawPath(shape)
        # The 9px tiny bump has NO text, shadow or icon.
        if h > 26:
            font = painter.font()
            font.setPointSize(10)
            font.setWeight(QFont.Weight.DemiBold)
            painter.setFont(font)
            painter.setPen(QColor(242, 242, 245))
            painter.drawText(
                QRectF(0, 0, w, min(35.0, h)),
                Qt.AlignmentFlag.AlignCenter,
                "ZEYVO",
            )
        painter.end()


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("ZEYVO Demo")
    app.setApplicationDisplayName("ZEYVO Classic Notch Demo")
    app.setQuitOnLastWindowClosed(False)
    asset = Path(__file__).resolve().parent / "assets" / "icon.png"
    if asset.is_file():
        app.setWindowIcon(QIcon(str(asset)))
    window = NotchWindow(app)
    window.show()
    return app.exec()
