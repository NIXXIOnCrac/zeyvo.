"""Pure layout and state constants for the cross-platform ZEYVO mini-notch.

Does not import Qt: this module can be unit-tested on any operating system.
"""
from __future__ import annotations

from dataclasses import dataclass

IDLE_MS = 30_000
PEEK = "peek"       # near-hidden: tiny clickable bump at top of display
REST = "rest"       # thin classic-style notch attached to top edge
OPEN = "open"       # interactive panel grows downward from notch


@dataclass(frozen=True)
class Dimensions:
    width: int
    height: int


SIZES = {
    PEEK: Dimensions(56, 9),
    REST: Dimensions(198, 36),
    OPEN: Dimensions(426, 342),
}


def anchored_position(
    mode: str,
    screen_x: int,
    screen_top: int,
    screen_width: int,
) -> tuple[int, int, int, int]:
    """Keep the notch flush with the TOP of its safe display rectangle.

    Caller selects screen_top: physical display top on Windows, menu-bar safe
    display top on macOS. We only center horizontally and preserve this y.
    """
    target = SIZES[mode]
    return (
        screen_x + (screen_width - target.width) // 2,
        screen_top,
        target.width,
        target.height,
    )


def label_for_mode(mode: str) -> str:
    return {PEEK: "Reveal ZEYVO", REST: "Open ZEYVO", OPEN: "Collapse ZEYVO"}[mode]
