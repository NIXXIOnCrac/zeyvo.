"""Tiny, deterministic ZEYVO demo conversation engine.

No network calls, API keys, accounts, recorded audio, or hidden tool use.
"""
from __future__ import annotations

from datetime import datetime
import re


def reply(message: str, now: datetime | None = None) -> str:
    text = re.sub(r"\s+", " ", message.strip().lower())
    now = now or datetime.now()
    if not text:
        return "Type a question and I’ll answer. Try: How are you?"
    if re.search(r"\b(how are you|how('?s| is) it going|you okay|what's up|wassup)\b", text):
        return "I'm doing great! Thanks for checking in. How's your day going?"
    if re.search(r"\b(hello|hi|hey|good morning|good evening|good afternoon|yo)\b", text):
        return "Hey there! I'm ZEYVO. What would you like to talk about?"
    if "who are you" in text or "what is zeyvo" in text or "what are you" in text:
        return "I'm ZEYVO — a tiny desktop companion. This is a local demo of my notch interface."
    if "what can you do" in text or "help" == text or "your features" in text:
        return "For now I can chat about a few things, tell jokes and give the time. The full ZEYVO is still being built."
    if "joke" in text or "make me laugh" in text:
        return "Why do programmers prefer dark mode? Because light attracts bugs."
    if "what time" in text or "the time" in text or "current time" in text:
        return f"It's {now.strftime('%I:%M %p').lstrip('0')} on your computer."
    if "what date" in text or "today's date" in text or "what day" in text:
        return f"Today is {now.strftime('%A, %B')} {now.day}, {now.year}."
    if "thank" in text:
        return "You're welcome! I'm right here whenever you need me."
    if "bye" in text or "good night" in text:
        return "See you soon! I'll be up here when you need me."
    if "stream" in text or "obs" in text or "fortnite" in text or "roblox" in text:
        return "Stream automation is a planned ZEYVO feature. This demo doesn't connect to OBS or your accounts yet."
    if "weather" in text:
        return "I don't have live weather access in this offline demo, but I can still keep you company!"
    if "name" in text:
        return "I don't know your name yet. This demo doesn't save personal details."
    return "I'm still just a small offline demo, so I can't answer everything yet. Try asking how I am, the time, or for a joke!"
