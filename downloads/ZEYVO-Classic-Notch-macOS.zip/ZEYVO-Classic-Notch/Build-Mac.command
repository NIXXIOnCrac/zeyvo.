#!/bin/bash
set -e
cd "$(dirname "$0")"
if [ ! -f .venv/bin/python ]; then
    python3 -m venv .venv
fi
.venv/bin/python -m pip install -r requirements-build.txt
.venv/bin/python -m PyInstaller --noconfirm --clean --windowed --onedir --name "ZEYVO Demo" --collect-data zeyvo_demo main.py
echo "The macOS application is in dist/ZEYVO Demo.app"
