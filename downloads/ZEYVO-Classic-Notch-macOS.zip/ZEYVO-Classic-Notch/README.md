# ZEYVO — Classic Notch Demo (Windows + macOS)

**Original minimal, classic iPhone-style black notch**, joined to the TOP EDGE of the display instead of floating like a Dynamic Island. The shape is inspired by a traditional display cutout, but it is not an actual macOS/Windows hardware notch and does not alter your monitor.

## What changed in this version

- **Solid black, no blue glow** and no decorative dots/circles; minimalist white lettering.
- **Flat top edge + rounded bottom corners**, not a floating rounded pill.
- **Three states:** full-size top-attached chat panel → slim notch → **very small 56 × 9 pixel bump**.
- After **30 seconds without interacting with ZEYVO**, it tucks down to just the tiny bump automatically. This measures ZEYVO usage only, not your computer's overall inactivity.
- Hover over the bump to reveal the notch, or click the notch/bump to open the chat. A menu-bar/system-tray icon also lets you reopen, tuck away, or quit.
- The whole notch stays horizontally centered when it changes size and animates smoothly from the **top edge**, growing downward.
- The Windows build uses the physical screen's top edge. The Mac build uses the **macOS usable top safe area**, avoiding interference with the menu bar or built-in camera cutout. On macOS, this means the notch may sit *below* the very top hardware bezel.
- Works without an API key. It only answers basic offline questions such as **"How are you?"**, **"What time is it?"**, and **"Tell me a joke"**.

**This is a typing-only proof of concept.** It does not listen for wake words, browse the web, launch Chrome, access your stream, or call online AI models. It doesn't start automatically on login: launch it yourself or configure your OS's login-items settings later if wanted.

## Windows — run the Python demo

1. Install **Python 3.10+** (check the "Add Python to PATH" option).
2. Extract the `ZEYVO-Classic-Notch-Windows.zip` package.
3. Double-click **`Run-on-Windows.bat`**. Internet is needed on the **first launch** to install Qt for Python (`PySide6`) to a local virtual environment.
4. Look for the small black notch centered on the top edge of your primary monitor. Click to open and type.
5. Wait 30 seconds without interacting to see it turn into the tiny bump; hover or click to reveal.
6. Use the Windows tray icon to **Open**, **Show small notch**, **Hide to tiny bump**, or **Quit**.

## macOS — run the Python demo

1. Install **Python 3.10+** (preferably from python.org).
2. Extract `ZEYVO-Classic-Notch-macOS.zip`.
3. Double-click **`Run-on-Mac.command`**. A Terminal window starts the demo; first launch installs PySide6 in its own virtual environment.
4. The notch sits below the menu-bar safe area where applicable. Depending on Mac model and display arrangement, this may not be at the physical top edge.
5. After 30 seconds without ZEYVO interactions, it shrinks to the tiny bump. Hover/click or use the menu-bar icon to bring it back.

If the extracted `.command` isn't executable: `chmod +x Run-on-Mac.command` from Terminal. Follow ordinary macOS application security guidance. Don't disable Gatekeeper or other security protections as a workaround.

## Create a standalone Windows `.exe` or Mac `.app`

The ZIPs contain the **Python source and build scripts, NOT precompiled signed apps**.

- On Windows, double-click **`Build-Windows.bat`** → `dist/ZEYVO-Demo/ZEYVO-Demo.exe` (keep the whole dist folder together).
- On a Mac, double-click **`Build-Mac.command`** → `dist/ZEYVO Demo.app`.
- Alternatively, push the source folder contents to a separate GitHub repository and manually run `.github/workflows/build.yml` to compile both platforms in native GitHub Actions runners. Download the resulting artifacts. Do not replace the main ZEYVO app's source with this prototype.

**Native unsigned builds have not been verified on an actual Windows PC or Mac during creation.** Release software requires QA, code signing and notarization as appropriate. Fullscreen games, macOS Spaces, other always-on-top windows, and display cutouts may prevent overlays from appearing where expected.

## Run unit tests

```shell
python -m pip install pytest
python -m pytest -q
```

No AI provider credentials or special operating-system permissions are required. All chat stays in the app's memory and nothing is uploaded or persisted by this demo.

## Important files

- `zeyvo_demo/app.py` — Qt native transparent window, painting, system tray and animation.
- `zeyvo_demo/layout.py` — display sizes, location math and 30-second idle configuration.
- `zeyvo_demo/responses.py` — deterministic, offline replies.
- `tests/` — basic behavior and layout tests.
- `.github/workflows/build.yml` — example standalone builders.
