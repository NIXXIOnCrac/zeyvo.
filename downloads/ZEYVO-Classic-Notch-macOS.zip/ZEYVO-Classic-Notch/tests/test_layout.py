from zeyvo_demo.layout import IDLE_MS, OPEN, PEEK, REST, SIZES, anchored_position, label_for_mode


def test_idle_is_30_seconds():
    assert IDLE_MS == 30_000


def test_tiny_bump_is_under_ten_pixels_tall():
    assert SIZES[PEEK].height <= 10
    assert SIZES[PEEK].width < SIZES[REST].width < SIZES[OPEN].width


def test_center_and_flush_to_safe_top():
    assert anchored_position(REST, 100, 28, 1400) == (701, 28, 198, 36)
    assert anchored_position(PEEK, -1600, 0, 1600) == (-828, 0, 56, 9)


def test_tray_labels():
    assert label_for_mode(PEEK) == "Reveal ZEYVO"
    assert label_for_mode(OPEN) == "Collapse ZEYVO"
