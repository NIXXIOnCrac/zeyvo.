from datetime import datetime
from zeyvo_demo.responses import reply


def test_greeting():
    assert "ZEYVO" in reply("Hey!")


def test_how_are_you():
    assert "great" in reply("How are you?")


def test_date():
    assert "2026" in reply("What day is it?", datetime(2026, 10, 19, 12, 20))


def test_time():
    assert "12:20 PM" in reply("What time is it", datetime(2026, 10, 19, 12, 20))


def test_no_fake_obs():
    assert "doesn't connect" in reply("Can you control my OBS stream?")


def test_no_fake_weather():
    assert "don't have live weather" in reply("What's the weather?")


def test_fallback():
    assert "offline demo" in reply("Quantum bananas in orbit")


def test_empty():
    assert "Type a question" in reply("  ")
