"""Optional GUI smoke test: runs in the Windows/macOS CI environment.

On hosts without Qt installed it skips; independent layout tests always run.
"""
import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

import pytest

pytest.importorskip('PySide6')

from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication
from zeyvo_demo.app import NotchWindow
from zeyvo_demo.layout import IDLE_MS, OPEN, PEEK, REST, SIZES


def test_three_window_states():
    app = QApplication.instance() or QApplication([])
    window = NotchWindow(app)
    window.show()
    assert window._mode == REST
    assert window._idle.interval() == IDLE_MS
    window.expand()
    QTest.qWait(400)
    assert window._mode == OPEN
    assert window.width() == SIZES[OPEN].width
    assert window.height() == SIZES[OPEN].height
    assert window.panel.isVisible()
    window.tuck_away()
    QTest.qWait(350)
    assert window._mode == PEEK
    assert window.height() == SIZES[PEEK].height
    assert not window.panel.isVisible()
    window.close()
